<?php

function retroLink($link, $type = 'text') {
	
	$api_url = 'http://retrolink.com.br/api/?url='.$link.'&type='.$type;
	
	if (is_callable('curl_init')) {
		
		$options = array (
			CURLOPT_URL               => $api_url,
			CURLOPT_HEADER            => false,
			CURLOPT_RETURNTRANSFER    => true
		);
		
		$ch = curl_init();
		curl_setopt_array($ch, $options);
		
		$result = curl_exec($ch);
		
		curl_close($ch);
		
	} else $result = file_get_contents($api_url);

	return $result;
	
}

// link a ser desprotegido
$link = $_GET['link'];


/*
  A API pode responder em 3 formatos. Escolha o que achar melhor.
  Note que o formato 'text' só exibe o link desprotegido.
*/

$text = retroLink($link);
$json = json_decode(retroLink($link, 'json'));
parse_str(retroLink($link, 'query'), $query);

echo $text;
echo '<br/><br/>';

print_r($json);
echo '<br/><br/>';

print_r($query);

/******************************************************************************

['success'] será preenchido da seguinte forma:
	1: Se o link desprotegido corresponder a um servidor de download conhecido.
	
	Note que a única forma de saber com certeza que um link foi desprotegido
	completamente é obter um link de um servidor de download. O link pode ser
	desprotegido e apontar para um site desconhecido e nesse casso ['success']
	será 0.
	

['error'] será preenchido da seguinte forma:
	
	0: Valor padrão. Não significa que o link foi desprotegido.
	1: O link original já era de um servidor de downloads.
	2: O link é de uma url não relacionada a protetores, como google.com.
	3: Protetor falso, exibe apenas propagandas e não tem links de download.
	4: O link foi desprotegido, mas corresponde a um servidor que não existe mais.
	5: O protetor tem captcha. O usuário deve preencher o captcha no protetor.
	6: Não foi possível desproteger o link.


Você pode exibir o link para seu visitante se ['success'] for 1 ou ['error'] for 0.
Também pode exibir o link se ['error'] for 1 e 4, mas certifique-se de instruir o
cliente sobre o link desprotegido.

******************************************************************************/

?>